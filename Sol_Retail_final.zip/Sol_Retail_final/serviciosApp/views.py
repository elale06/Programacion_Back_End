from django.shortcuts import render
from .models import Servicio

def servicios(request):
    datos = Servicio.objects.select_related("precioservicio").all()
    return render(request, "servicios/servicios.html", {"servicios": datos})

def precios(request):
    datos = Servicio.objects.select_related("precioservicio").all()
    return render(request, "precios/precios.html", {"servicios": datos})
