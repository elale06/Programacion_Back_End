from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('menuApp.urls')),
    path('informacion/', include('infoApp.urls')),
    path('servicios/', include('serviciosApp.urls')),
]
