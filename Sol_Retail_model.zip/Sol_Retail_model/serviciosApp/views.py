import json
from pathlib import Path
from django.http import HttpResponse
from django.shortcuts import render
from.models import Servicio, PrecioServicio

def cargar_datos():
    archivo = Path(__file__).resolve().parent / "datos.json"
    with open(archivo, "r", encoding="utf-8") as archivo_json:
        datos = json.load(archivo_json)

    return [
        {"id": servicio["pk"], **servicio["fields"]}
        for servicio in datos
    ]

def servicios(request):
    datos = cargar_datos()
    return render(request, "servicios/servicios.html", {"servicios": datos})

def precios(request):
    return render(request, "precios/precios.html", {"servicios": cargar_datos()})
